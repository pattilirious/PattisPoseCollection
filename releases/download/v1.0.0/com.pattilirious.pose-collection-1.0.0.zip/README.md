Required dependencies:
- VRCFury (https://vcc.vrcfury.com)
- Gesture Manager

Instruction:
- Open VCC > Settings > Packages > Add Repositories and paste this in the text box: https://github.com/pattilirious/PattisPoseCollection/index.json
- Open Pose folder and just drag the prefab into your avatar and it should work as long as you have VRCFury added in your project. 
- There is an ERP Pose system inside the Pose folder, the folder name is YaokiSubWork. It's optional but if you want it in your avatar, just open the folder and drag the prefab into your avatar. If you have Airi, Lasyusha, Manuka, Moe, Selestia, or Shinano, drag the proper prefab for them. If you're not using any of those avatar mentioned, just drag "Catchable ERP system.prefab" into your avatar. There is another ERP pose already added in the prefab and it's called ""

Known Issue:
- Toggles doesn't turn off automatically and you have to turn it off when you have to do another pose.
